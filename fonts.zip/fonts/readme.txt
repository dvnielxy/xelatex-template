Para instalar las fuentes:
1. Seleccionar todas.
2. Clic derecho e instalar.
3. Listo.